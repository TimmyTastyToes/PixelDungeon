#created on may 29

import pgzrun
from random import randint
from pygame import mixer
from pygame.math import Vector2
from pgzero.actor import Actor
import time
import pygame


WIDTH = 1500
HEIGHT = 800
TITLE = 'Goobie Woobies V3'

Random_LOC = (randint(100, 400), randint(100, 400))

#Cursor
Cursor = Actor('cursor.png')

#X-Ray
X_Ray = False

#Cash
Cash_AMNT = 1
Cash = Actor('cash.png')
Cash.pos = (1150, 40)
Cash_Coll = False

#CLOUDS

Cloud1 = Actor('cloud1.png')
Cloud1_Spawn = randint(1, 11)
Cloud1.y = randint(10, 30)
Cloud1.x = randint(-100, 350)

Cloud2 = Actor('cloud2.png')
Cloud2_Spawn = randint(10,350)
Cloud2.y = randint(10, 30)
Cloud2.x = randint(-100, 350)

Cloud3 = Actor('cloud3.png')
Cloud3_Spawn = randint(10,350)
Cloud3.y = randint(10, 30)
Cloud3.x = randint(-100, 350)

Cloud4 = Actor('cloud1.png')
Cloud4_Spawn = randint(10,350)
Cloud4.y = randint(10, 30)
Cloud4.x = randint(-100, 350)

Cloud5 = Actor('cloud2.png')
Cloud5_Spawn = randint(10,350)
Cloud5.y = randint(10, 30)
Cloud5.x = randint(-100, 350)

Cloud6 = Actor('cloud3.png')
Cloud6_Spawn = randint(10,350)
Cloud6.y = randint(10, 30)
Cloud6.x = randint(-100, 350)

Cloud7 = Actor('cloud1.png')
Cloud7_Spawn = randint(10,350)
Cloud7.y = randint(10, 30)
Cloud7.x = randint(-100, 350)

Cloud8 = Actor('cloud2.png')
Cloud8_Spawn = randint(10,350)
Cloud8.y = randint(10, 30)
Cloud8.x = randint(-100, 350)

Cloud9 = Actor('cloud3.png')
Cloud9_Spawn = randint(10,350)
Cloud9.y = randint(10, 30)
Cloud9.x = randint(-100, 350)


#---Sound_Library---#

Cute_Pop = mixer.Sound('Cute_Pop.wav')
Goodbye = mixer.Sound('Goodbye.wav')
Startup = mixer.Sound('Startup.wav')
Happy_Block = mixer.Sound('Happy_Block.wav')
Block_Chirp = mixer.Sound('block_chirp.wav')
Button_Hover = mixer.Sound('button_hover.mp3')
Money = mixer.Sound('money.wav')
Money2 = mixer.Sound('money2.wav')
Eating = mixer.Sound('eating.wav')
Bat_Screech = mixer.Sound('bat.wav')
Bat_Screech.set_volume(0.2)

#START
Startup.play()

#---Bat--- $10 = $15#
Bat_Icon = Actor('bat_icon.png')
Bat_Icon.pos = (350, 100)
Bat_Icon_Visible = False
Bat_Moving = False

Bat_Spawned = False
Bat = Actor('bat.png')
Bat.y = 500
Bat.x = 500
Bat_Picked_Up = False
Bat_Cooldown = False
Bats = []
Bat_AMNT = 0

#---BLOCK---#
 
block = Actor('happy_block.png')
block_velocity = 0
gravity = 5
bottom_boundary = HEIGHT - 35
reached_bottom = False
block_spawned = False
blocks = []
block.y = randint(100, 800)
block.x = randint(100, 800)
block_picked_up = False
block_moving = False
block_AMNT = 0

#FATSO $20 - $30
Fatso_Value = 20
Fatso = Actor('fatso.png')
Fatso.y = (10)
Fatso.x = (50)
Fatso_Picked_Up = False
Fatso_Purchase = False
Fatso_AMNT = 0

Fatso_Icon = Actor('fatso_icon.png')
Fatso_Icon_Visible = False
Fatso_Icon.pos = (460, 100)
Fatso_Speed = 0.05
    
#---exit_menu---#

exit_menu = Actor('exit_menu.png')

exit_menu.pos = (800, 200)

exit_menu_visible = False

#---play_button---#

play_button = Actor('play_icon.png')

play_button_hovered_image = ('play_icon_hovered.png')

play_button.pos = (700, 100)

play_button_hovered = False

play_button_hovered_offset = (-50, -50)

play_button_visible = False

#---exit_button---#

exit_button = Actor('exit_icon.png')

exit_button.pos = (700, 250)

exit_button_visible = False

#---Side_Panel---#

side_panel_image = 'side_panel.png'

side_panel_1 = Actor(side_panel_image)

side_panel_1.pos = (50, 10)


side_panel_image_2 = 'side_panel.png'

side_panel_2 = Actor(side_panel_image)

side_panel_2.pos = (50, 100)


side_panel_image_3 = 'side_panel.png'

side_panel_3 = Actor(side_panel_image)

side_panel_3.pos = (50, 150)


side_panel_image_4 = 'side_panel.png'

side_panel_4 = Actor(side_panel_image)

side_panel_4.pos = (50, 200)


side_panel_image_5 = 'side_panel.png'

side_panel_5 = Actor(side_panel_image)

side_panel_5.pos = (50, 250)


side_panel_image_6 = 'side_panel.png'

side_panel_6 = Actor(side_panel_image)

side_panel_6.pos = (50, 300)


side_panel_image_7 = 'side_panel.png'

side_panel_7 = Actor(side_panel_image)

side_panel_7.pos = (50, 350)


side_panel_image_8 = 'side_panel.png'

side_panel_8 = Actor(side_panel_image)

side_panel_8.pos = (50, 400)


side_panel_image_9 = 'side_panel.png'

side_panel_9 = Actor(side_panel_image)

side_panel_9.pos = (50, 450)


side_panel_image_10 = 'side_panel.png'

side_panel_10 = Actor(side_panel_image)

side_panel_10.pos = (50, 500)


side_panel_image_11 = 'side_panel.png'

side_panel_11 = Actor(side_panel_image)

side_panel_11.pos = (50, 550)


side_panel_image_12 = 'side_panel.png'

side_panel_12 = Actor(side_panel_image)

side_panel_12.pos = (50, 600)


side_panel_image_13 = 'side_panel.png'

side_panel_13 = Actor(side_panel_image)

side_panel_13.pos = (50, 650)


side_panel_image_14 = 'side_panel.png'

side_panel_14 = Actor(side_panel_image)

side_panel_14.pos = (50, 700)


side_panel_image_15 = 'side_panel.png'

side_panel_15 = Actor(side_panel_image)

side_panel_15.pos = (50, 750)


side_panel_image_16 = 'side_panel.png'

side_panel_16 = Actor(side_panel_image)

side_panel_16.pos = (50, 800)

#---ITEMS---#

delete_button_image = 'delete_icon.png'

delete_button_hovered_image = 'delete_icon_hovered'

delete_button_hovered = False

delete_button_hovered_offset = (-60, -50)

delete_button = Actor(delete_button_image)

delete_button.pos = (50, 430)

#---Settings---#

settings_button_image = 'settings_icon.png'

settings_button_hover_image = 'settings_hover_icon.png'

settings_button = Actor(settings_button_image)

settings_button.pos = (50, 130)

settings_button_hovered = False

settings_button_hovered_offset = (-50, -50)

#---Toolbar---#

toolbar_button_image = 'toolbar_icon.png'

toolbar_button_hover_image = 'toolbar_hover_icon.png'

toolbar_button = Actor(toolbar_button_image)

toolbar_button.pos = (55, 30)

toolbar_button_hovered = False

toolbar_button_hover_offset = (-90, -100)



#---Spawn_Menu---#

spawn_menu_image = 'spawn_menu.png'

spawn_menu = Actor(spawn_menu_image)

spawn_menu.pos = (400, 200)

spawn_menu_visible = False

#---Spawn_Button---#

block_spawn_button = Actor('block_button.png')

block_spawn_button.pos = (250, 100)

block_spawn_button_visible = False

spawn_button_cooldown = False

blocks = []

#---color---#
Red = randint(-1, 256)
Green = randint(-1, 256)
Blue = randint(-1, 256)

color = (Red, Green, Blue)

RGB_Button = Actor('color_icon.png')
RGB_Button_Visible = False
RGB_Button.pos = (700, 175)

New_Color_Change = False
#shadow
Shadow_Rect = Rect(1450, 1, 100, 800)
Shadow_Rect2 = Rect(1, 1, 1600, 40)
ShadowR = Red - 20
ShadowG = Green - 20
ShadowB = Blue - 20

Shadow_color = (ShadowR, ShadowG, ShadowB)


#---HSOUE---#
#icon
House_Icon = Actor('house_icon.png')
House_Icon.pos = (50, 230)
House_Icon_Hovered = False
House_Icon_Hovered_Image = 'house_icon_hovered.png'
House_Icon_Hovered_Offset = (-60, -50)
#menu
House_Menu = Actor('spawn_menu.png')
House_Menu_Visible = False
House_Menu.pos = (800, 200)

#house 
House = Actor('house.png')
House_Location = randint(100, 1400)
House.pos = ((House_Location), (750))

#house2 $10
House2_icon = Actor('house_level2_icon.png')
House2_icon_Visible = False
House2_icon.pos = (650, 150)
House2 = Actor('house_level2.png')
House2.pos = House.pos
House2_Bought = False

#house3 $50
House3_icon = Actor('house_level3_icon.png')
House3_icon_Visible = False
House3_icon.pos = (750, 150)
House3 = Actor('house_level3.png')
House3_Bought = False
House3.pos = House.pos

#house4 $150
House4_icon = Actor('house_level4_icon.png')
House4_icon_Visible = False
House4_icon.pos = (850, 150)
House4 = Actor('house_level4.png')
House4.y = House.y - 50
House4.x = House.x
House4_Bought = False

#house5 $200
House5_icon = Actor('house_level5_icon.png')
House5_icon_Visible = False
House5_icon.pos = (950, 150)
House5 = Actor('house_level5')
House5.y = House.y - 50
House5.x = House.x
House5_Bought = False

#background
Background = Actor('background.png')
Background.pos = (500, 500)


#Tutorial_Icon
Tutorial_Icon = Actor('tutorial_icon.png')
Tutorial_Icon.pos = (50, 330)
Tutorial_Icon_Hovered = False
Tutorial_Icon_Hovered_Image = ('tutorial_icon_hovered.png')
Tutorial_Icon_Hovered_Offset = (-50, -50)

Tutorial_Menu = Actor('spawn_menu.png')
Tutorial_Menu.pos = (600, 400)
Tutorial_Menu_Visible = False

Tutorial = '''Hello, Welcome To The Tutorial,
There's Not Much To Know...Just Put
The Goobies In The TreeHouse, Get Cash
Upgrade And Repeat :/

Live Long And Prosper


-Liam'''

#clouds
Clouds_List = [Cloud1, Cloud2, Cloud3, Cloud4, Cloud5, Cloud6, Cloud7, Cloud8, Cloud9]
Cloud_Index = randint(0, len(Clouds_List)-1)
Clouds = Clouds_List[Cloud_Index]

#Angel
Angel_Icon = Actor('angel_icon.png')
Angel_Icon.pos = (250, 200)
Angel_Icon_Visible = False
Angel = Actor('angel.png')
Angel_Bought = False
Angel.x = randint(50, 500)
Angel.y = randint(50, 500)
Hiding = False
Angel_Picked_Up = False

#Seeker
Seeker_Icon = Actor('seeker_icon.png')
Seeker_Icon.pos = (350, 200)
Seeker_Icon_Visible = False
Seeker_Bought = False

Seeker = Actor('seeker.png')
Seeker.x = randint(50, 500)
Seeker.y = randint(50, 500)
Seeking = False



#---ON_MOUSE_DOWN---#

def on_mouse_down(pos):
    global spawn_menu_visible, exit_menu_visible, play_button_visible, exit_button_visible, block_spawn_button_visible, block_amount, block_spawned, block_spawn, block, spawn_button_cooldown, block_picked_up, Cash_AMNT, Cah_Coll, RGB_Button_Visible, House_Menu_Visible, House2_icon_Visible, House2_icon, House2_Bought, House2_icon_Visible, House3_icon_Visible, House3_Bought, House4_icon_Visible, House4_Bought, House5_icon_Visible, House5_Bought
    global Bat_Icon_Visible, Bat_Spawned, Bat, Bat_Picked_Up, Cash_Sound, Red, Green, Blue, color, Fatso_Icon_Visible, Fatso_Icon, Fatso_Purchase, Fatso_Speed
    global Bat_Moving, Shadow_Rect, Shadow_Color, block_moving, Bat_AMNT, block_AMNT, Fatso_AMNT, Angel_Icon_Visible, Angel_Bought
    global Angel, Angel_Picked_Up, Tutorial_Menu_Visible, Seeker_Icon_Visible, Seeker_Bought
    
    #toolbar
    if toolbar_button.collidepoint(pos):
        Cute_Pop.play()
        print("Toolbar Clicked")
        spawn_menu_visible = not spawn_menu_visible
        exit_menu_visible = False
        play_button_visible = False
        exit_button_visible = False
        block_spawn_button_visible = True
        RGB_Button_Visible = False
        House_Menu_Visible = False
        House2_icon_Visible = False
        House3_icon_Visible = False
        House4_icon_Visible = False
        House5_icon_Visible = False
        Bat_Icon_Visible = True
        Fatso_Icon_Visible = True
        Tutorial_Menu_Visible = False
        Seeker_Icon_Visible = True
    

    else:
        block_spawn_button_visible = False
        Bat_Icon_Visible = False
        Fatso_Icon_Visible = False
        Seeker_Icon_Visible = False
        
    #Settings
    if settings_button.collidepoint(pos):
        global RBG_Button_Visible
        Cute_Pop.play()
        print("Settings Clicked")
        spawn_menu_visible = False
        exit_menu_visible = not exit_menu_visible
        play_button_visible = not play_button_visible
        exit_button_visible = not exit_button_visible
        block_spawn_button_visible = False
        RGB_Button_Visible = not RGB_Button_Visible
        House_Menu_Visible = False
        House2_icon_Visible = False
        House3_icon_Visible = False
        House4_icon_Visible = False
        House5_icon_Visible = False
        Bat_Icon_Visible = False
        Fatso_Icon_Visible = False
        Tutorial_Menu_Visible = False

    #play
    if play_button.collidepoint(pos) and play_button_visible:
        Cute_Pop.play()
        exit_menu_visible = False
        play_button_visible = False
        exit_button_visible = False
        RGB_Button_Visible = False
        House_Menu_Visible = False
        House2_icon_Visible = False
        House3_icon_Visible = False
        House4_icon_Visible = False
        House5_icon_Visible = False
        Bat_Icon_Visible = False
        Fatso_Icon_Visible = False
        Tutorial_Menu_Visible = False

    #exit

    if exit_button.collidepoint(pos) and exit_button_visible:
        Goodbye.play()
        while mixer.get_busy():
            pass
        quit()
        
    #COLOR
    if RGB_Button.collidepoint(pos) and RGB_Button_Visible:
        Red = randint(-1, 256)
        Green = randint(-1, 256)
        Blue = randint(-1, 256)

        #shadow
        ShadowR = Red - 50
        ShadowG = Green - 50
        ShadowB = Blue - 50

        Shadow_color = (ShadowR, ShadowG, ShadowB)

        color = (Red, Green, Blue)

        Cute_Pop.play()
        


    #Items
    if delete_button.collidepoint(pos):
        print('Nothing To See Here')
        Cute_Pop.play()

    #BLOCK_BUTTON
    if block_spawn_button.collidepoint(pos) and spawn_menu_visible and spawn_button_cooldown == False and Cash_AMNT > 0:
        print("blocky guy selected")
        block_spawned = True
        Cute_Pop.play()
        block = not None
        Cash_AMNT -= 1
        spawn_menu_visible = False
        block_moving = True
        block_AMNT += 1

        def spawn_block():
             global block
             block = Actor('happy_block.png')
             block.y = randint(100, 650)
             block.x = randint(100, 1500)

        if block_spawned:
             spawn_block()
             block_spawned = True
             blocks.append(block)

        spawn_button_cooldown = True


    #CASH

    if block_spawn_button.collidepoint(pos) and spawn_menu_visible:
        Cash_Coll == False

    #BLOCKPIC

    if block.collidepoint(pos) and block_spawned == True:
        block_picked_up = not block_picked_up
        Block_Chirp.play()

    #HOUSE

    if House_Icon.collidepoint(pos):
        Cute_Pop.play()
        House_Menu_Visible = not House_Menu_Visible
        exit_menu_visible = False
        play_button_visible = False
        RGB_Button_Visible = False
        spawn_menu_visible = False
        exit_button_visible = False
        Bat_Icon_Visible = False
        Fatso_Icon_Visible = False
        House2_icon_Visible = not House2_icon_Visible
        House3_icon_Visible = not House3_icon_Visible
        House4_icon_Visible = not House4_icon_Visible
        House5_icon_Visible = not House5_icon_Visible
        Tutorial_Menu_Visible = False

    #HOUSe2
    if House2_icon.collidepoint(pos) and House2_icon_Visible and Cash_AMNT > 10:
        Cute_Pop.play()
        House2_Bought = True
        Cash_AMNT -= 10
        House.y += 10
        cash1 = mixer.Sound('cash1.wav')
        cash2 = mixer.Sound('cash2.wav')
        cash3 = mixer.Sound('cash3.wav')
        cash4 = mixer.Sound('cash4.wav')
    
        Random_Cash_list = [cash1, cash2, cash3, cash4]
        Random_Cash_Index = randint(0, len(Random_Cash_list)-1)
        Cash_Sound = Random_Cash_list[Random_Cash_Index]
        Cash_Sound.play()

    #house3

    if House3_icon.collidepoint(pos) and House3_icon_Visible and Cash_AMNT > 50:
        Cute_Pop.play()
        Cash_AMNT -= 50
        House.y += 10
        House3_Bought = True
        cash1 = mixer.Sound('cash1.wav')
        cash2 = mixer.Sound('cash2.wav')
        cash3 = mixer.Sound('cash3.wav')
        cash4 = mixer.Sound('cash4.wav')
    
        Random_Cash_list = [cash1, cash2, cash3, cash4]
        Random_Cash_Index = randint(0, len(Random_Cash_list)-1)
        Cash_Sound = Random_Cash_list[Random_Cash_Index]
        Cash_Sound.play()

    #house4

    if House4_icon_Visible and House4_icon.collidepoint(pos) and Cash_AMNT > 250:
        Cute_Pop.play()
        Cash_AMNT -= 250
        House4_Bought= True
        cash1 = mixer.Sound('cash1.wav')
        cash2 = mixer.Sound('cash2.wav')
        cash3 = mixer.Sound('cash3.wav')
        cash4 = mixer.Sound('cash4.wav')
    
        Random_Cash_list = [cash1, cash2, cash3, cash4]
        Random_Cash_Index = randint(0, len(Random_Cash_list)-1)
        Cash_Sound = Random_Cash_list[Random_Cash_Index]
        Cash_Sound.play()

    #HOUSE5

    if House5_icon_Visible and House5_icon.collidepoint(pos) and Cash_AMNT > 500:
        Cute_Pop.play()
        Cash_AMNT -= 500
        House5_Bought = True
        cash1 = mixer.Sound('cash1.wav')
        cash2 = mixer.Sound('cash2.wav')
        cash3 = mixer.Sound('cash3.wav')
        cash4 = mixer.Sound('cash4.wav')
    
        Random_Cash_list = [cash1, cash2, cash3, cash4]
        Random_Cash_Index = randint(0, len(Random_Cash_list)-1)
        Cash_Sound = Random_Cash_list[Random_Cash_Index]
        Cash_Sound.play()

    if House5_Bought and House4_Bought:
        House4_Bought = False
    #BAT
    if Bat_Icon.collidepoint(pos) and Cash_AMNT > 10 and spawn_menu_visible and not Bat_Moving:
        Bat.pos = (500, 500)
        Cute_Pop.play() 
        Bat_Spawned = True
        Cash_AMNT -= 10
        Bat = Actor('bat.png')
        spawn_menu_visible = False
        Bat_Moving = True
        Bat_AMNT += 1
            
        Bat_Cooldown = True

    if Bat_Spawned and Bat.collidepoint(pos):
        Bat_Picked_Up = not Bat_Picked_Up
        
    #Fatso
    if Fatso_Icon.collidepoint(pos) and spawn_menu_visible and Cash_AMNT > 20 and not Fatso_Purchase:
        Cash_AMNT -= 20
        Cute_Pop.play()
        spawn_menu_visible = False
        Fatso.pos = (50, 50)
        Fatso_Value = 20
        Fatso_Speed = 0.05
        Fatso_Purchase = True
        Fatso_AMNT += 1


    #tutorial
    if Tutorial_Icon.collidepoint(pos):
        spawn_menu_visible = False
        exit_menu_visible = False
        House_Menu_Visible = False
        House2_icon_Visible = False
        House3_icon_Visible = False
        House4_icon_Visible = False
        House5_icon_Visible = False
        Bat_Icon_Visible = False
        Fatso_Icon_Visible = False
        play_button_visible = False
        RGB_Button_Visible = False
        spawn_menu_visible = False
        exit_button_visible = False
        Tutorial_Menu_Visible = True
        Cute_Pop.play()
    #ANGEL
    if Angel_Icon.collidepoint(pos) and Angel_Icon_Visible and spawn_menu_visible and Cash_AMNT >= 30 and Angel_Bought == False:
        Cute_Pop.play()
        Cash_AMNT -= 30
        Angel_Icon_Visible = False
        spawn_menu_visible = False
        Angel_Bought = True
        Angel.pos = (500, 500)
        Clouds_List = [Cloud1, Cloud2, Cloud3, Cloud4, Cloud5, Cloud6, Cloud7, Cloud8, Cloud9]
        Cloud_Index = randint(0, len(Clouds_List)-1)
        Clouds = Clouds_List[Cloud_Index]
        
    if Angel.collidepoint(pos) and Angel_Bought:
        Angel_Picked_Up = not Angel_Picked_Up

    #Seeker
    if Seeker_Icon.collidepoint(pos) and Cash_AMNT > 50 and spawn_menu_visible and Seeker_Bought == False:
        Cute_Pop.play()
        Seeker_Icon_Visible = False
        spawn_menu_visible = False
        Cash_AMNT -= 50
        Seeker_Bought = True


#---Mouse_MOVE---#
def on_mouse_move(pos):
    global toolbar_button_hovered, settings_button_hovered, play_button_hovered, delete_button_hovered, block_picked_up, House_Icon_Hovered, House2_icon_Visible
    global Bat_Picked_Up, Tutorial_Icon_Hovered, Angel_Bought, Angel_Picked_Up

    #Cursor
    Cursor.pos = pos
    #toolbar
    if toolbar_button.collidepoint(pos):
        toolbar_button_hovered = True

    else:
        toolbar_button_hovered = False


    #settings
    if settings_button.collidepoint(pos):
        settings_button_hovered = True

    else:
        settings_button_hovered = False

    #play

    if play_button.collidepoint(pos) and play_button_visible:
        play_button_hovered = True

    else:
        play_button_hovered = False

    #delete_button

    if delete_button.collidepoint(pos):
        delete_button_hovered = True

    else:
        delete_button_hovered = False

    if block_picked_up:
        block.pos = pos

    #house

    if House_Icon.collidepoint(pos):
        House_Icon_Hovered = True

    else:
        House_Icon_Hovered = False

    #block

    if Bat_Picked_Up:
        Bat.pos = pos

    #tutorial
    if Tutorial_Icon.collidepoint(pos):
        Tutorial_Icon_Hovered = True
    else:
        Tutorial_Icon_Hovered = False

    if Angel_Picked_Up:
        Angel.pos = pos

    
    
#---Exit---#
        
#--UPDate===#
def update():
    global block_spawn, block_spawned, block, blocks, block_spawn_button_visible, spawn_button_cooldown, reached_bottom, block_picked_up, Cash_AMNT, Cash_Coll, RGB_Button_Visible, New_Color_Change, Min_VOL, Max_Vol, Bat_Icon_Visible
    global Bat_Cooldown, New_Color_Change, Fatso, Fatso_Purchase, Fatso_Value, Bat_Picked_Up, Fatso_Speed, Animation, Bat_Moving
    global block_moving, Angel_Bought, Hiding, Angel_Picked_Up, Clouds, Clouds_List, Cloud_Index, Seeker, Seeker_Bought, Seeking
    
    #updated var
    Fatso
    Fatso_Purchase
    New_Color_Change
    
    #BLOCK
    if  block.y <= bottom_boundary and block_spawned and not block_picked_up and block_moving:
        block.y = block.y + randint(1, 6)
        block.x = block.x + randint(-6, 6)
        block_spawn_button_visible == False
        
    if block.y >= bottom_boundary and not block_picked_up and block_moving:
        block_spawned == False
        block_spawn_button_visible = True
        spawn_button_cooldown = False
        reached_bottom = True
        block.x = block.x + randint(-50, 50)

        if block.x <= (-1):
            block.x = block.x + 100
            Block_Chirp.play()

        if block.x >= (1500):
            block.x -= 100
            Block_Chirp.play()

        if block.colliderect(House):
            Seeking = True
            block.pos = (600, 1000)
            Cash_AMNT = Cash_AMNT + 2
            block_moving = False
            if Cash_AMNT >= 100:
                Money.play()
            else:
                Money2.play()
    #BAT
    if Bat_Spawned and not Bat_Picked_Up and Bat_Moving:
        Bat.y += randint(-1, 1)
        Bat.x += randint(-1, 1)

        if Cursor.y >= Bat.y + 10 and Bat_Moving:
            Bat.y -= 5

        if Cursor.y <= Bat.y - 10 and Bat_Moving:
            Bat.y += 5

        if Cursor.x >= Bat.y + 10 and Bat_Moving:
            Bat.x -= 5

        if Cursor.x <= Bat.y - 10 and Bat_Moving:
            Bat.x += 5

        if Bat.colliderect(House) and not Bat_Picked_Up and Bat_Moving:
            Cash_AMNT += 15
            Bat.pos = (50, 5000)
            Bat_Screech.play()
            Bat_Moving = False
            if Cash_AMNT >= 100:
                Money.play()
            else:
                Money2.play()

            

    if Bat.y <= (100) and Bat_Moving:
        Bat.y += 100

    if Bat.x <= (100) and Bat_Moving:
        Bat.x += (10)

    if Bat.y >= bottom_boundary and Bat_Moving:
        Bat.y -= 10

    if Bat.x >= 1500 and Bat_Moving:
        Bat.x -= 50
        


    #chirp
    Min_VOL = 10
    Max_VOL = 100

    Random_VOL = randint(Min_VOL, Max_VOL) / 100.0

    Block_Chirp.set_volume(Random_VOL)

    #Fatso

    if Fatso.y <= bottom_boundary and Fatso_Purchase:
        Fatso.y = Fatso.y + 10
    if Fatso.y >= bottom_boundary and Fatso_Purchase:
        Fatso.x += (Fatso_Speed)

    if Fatso.colliderect(House) and Fatso_Purchase:
        Fatso.pos = (50, 1000)
        Cash_AMNT += 35 and Fatso_Value
        Fatso_Purchase = False
        Fatso_Value = 20
        if Cash_AMNT >= 100:
            Money.play()
        else:
            Money2.play()

    if Fatso.colliderect(Bat):
        Bat.pos = (500, 9000)
        Fatso_Value += 15
        Fatso_Speed += 0.05
        Bat_Picked_Up = False
        print("Bat Collected")
        Eating.play()
        Bat_Moving = False

    if Fatso.colliderect(block) and not block_picked_up:
        block.pos = (500, 9000)
        Fatso_Value += 5
        Fatso_Speed += 0.05
        Eating.play()

    #if House5_Bought:
        #Animation.x += 1

    #CLOUD
    #1
    if Cloud1.x != 1500:
        Cloud1.x += randint(1, 5) / 5

        if Cloud1.x >= 1700:
            Cloud1.x = randint(1, 11)
            Cloud1.y = randint(1, 30)
            Cloud1_Spawn = randint(-11, 11)

    #2
    if Cloud2.x != 1500:
        Cloud2.x += randint(1, 10) / 10

        if Cloud2.x >= 1700:
            Cloud2.x = randint(-11, 11)
            Cloud2.y = randint(1, 30)
            Cloud2_Spawn = randint(1, 11)

        #3
    if Cloud3.x != 1500:
        Cloud3.x += randint(1, 10) / 15

        if Cloud3.x >= 1700:
            Cloud3.x = randint(-11, 11)
            Cloud3.y = randint(1, 30)
            Cloud3_Spawn = randint(1, 11)
    #4
    if Cloud4.x != 1500:
        Cloud4.x += randint(1, 10) / 20

        if Cloud4.x >= 1700:
            Cloud4.x = randint(-11, 11)
            Cloud4.y = randint(1, 30)
            Cloud4_Spawn = randint(1, 11)
     #5
    if Cloud5.x != 1500:
        Cloud5.x += randint(1, 10) / 25

        if Cloud5.x >= 1700:
            Cloud5.x = randint(-11, 11)
            Cloud5.y = randint(1, 30)
            Cloud5_Spawn = randint(1, 11)
    #6
    if Cloud6.x != 1500:
        Cloud6.x += randint(1, 10) / 30

        if Cloud6.x >= 1700:
            Cloud6.x = randint(-11, 11)
            Cloud6.y = randint(10, 30)
            Cloud6_Spawn = randint(1, 11)

    #7
    if Cloud7.x != 1500:
        Cloud7.x += randint(1, 10) / 35

        if Cloud7.x >= 1700:
            Cloud7.x = randint(-11, 11)
            Cloud7.y = randint(1, 30)
            Cloud7_Spawn = randint(1, 11)
    #8
    if Cloud8.x != 1500:
        Cloud8.x += randint(1, 10) / 40

        if Cloud8.x >= 1700:
            Cloud8.x = randint(-11, 11)
            Cloud8.y = randint(1, 30)
            Cloud8_Spawn = randint(1, 11)
      #9      
    if Cloud9.x != 1500:
        Cloud9.x += randint(1, 10) / 40

        if Cloud9.x >= 1700:
            Cloud9.x = randint(-11, 11)
            Cloud9.y = randint(1, 30)
            Cloud9_Spawn = randint(1, 11)
            

    #angel
    if Angel_Bought and Hiding == False:
        Top_Boundary = 42

        if Angel.y >= Top_Boundary and Angel_Picked_Up == False:
            Angel.y -= randint(1, 10)
            Angel.x += randint(-5, 5)
        else:
            Angel.x += randint(-10, 10)

    if Angel.colliderect(Cloud1) or Angel.colliderect(Cloud2) or Angel.colliderect(Cloud3) or Angel.colliderect(Cloud4) or Angel.colliderect(Cloud5) or Angel.colliderect(Cloud6) or Angel.colliderect(Cloud7) or Angel.colliderect(Cloud8) or Angel.colliderect(Cloud9):
        Hiding == True
        Angel.pos = Clouds.pos


    if Angel.colliderect(House):
        Cash_AMNT += 45
        if Cash_AMNT >= 100:
            Money.play()
        else:
            Money2.play()
        Angel_Picked_Up = False
        Angel.pos = (-800, -800)
        Angel_Bought = False

    #seeker
    if Seeker_Bought and Seeker.y <= bottom_boundary:
        Seeker.y += 5
        Seeker.x += randint(-1, 1)

    if Seeker_Bought and Seeker.y >= bottom_boundary:
        Seeking = True

        if Seeking:
            if block.x <= Seeker.x - 50:
                Seeker.x -= 10

            if block.x >= Seeker.x + 50:
                Seeker.x += 10

    if Seeker.colliderect(block):
        Seeking = False
        block.pos = Seeker.pos

        if House.x <= Seeker.x:
            Seeker.x -= 10
            
        if House.x >= Seeker.x:
            Seeker.x += 10
            

    




def on_key_down(key):
    global Cash_AMNT, X_Ray
    if key == keys.C:
        print("CHEATER!")
        Cash_AMNT += 999998

    if key == keys.X:
        X_Ray = not X_Ray

    
        
#---Draw_Sreen---#

def draw():
    global spawn_block, block, Cash_AMNT, RGB_Button_Visible, New_Color_Change, House_Menu_Visible, House_Icon_Hovered, House3_icon_Visible
    global Bats, Fatso_Icon_Visible, Fatso_Purchase, Fatso, Cloud1_Spawn, Cloud2_Spawn, Cloud3_Spawn, Cloud4_Spawn, Cloud5_Spawn, Cloud6_Spawn, Cloud7_Spawn, Cloud8_Spawn, Cloud9_Spawn
    global X_Ray,Shadow_Rect, Shadow_color, Bat_AMNT, block_AMNT, Fatso_AMNT, Tutorial_Icon_Hovered, Angel_Icon_Visible
    global Tutorial_Menu_Visible, Seeker_Bought
    screen.clear()
    screen.fill(color)
    #shadow
    screen.draw.filled_rect(Shadow_Rect, Shadow_color)
    screen.draw.filled_rect(Shadow_Rect2, Shadow_color)
   #angel
    if Angel_Bought:
        Angel.draw()
    #cloud
    if Cloud1_Spawn > 5:
        Cloud1.draw()

    if Cloud2_Spawn >= 3:
        Cloud2.draw()

    if Cloud3_Spawn == 6:
        Cloud3.draw()

    if Cloud4_Spawn > 5:
        Cloud4.draw()

    if Cloud5_Spawn > 5:
        Cloud5.draw()

    if Cloud6_Spawn > 5:
        Cloud6.draw()

    if Cloud7_Spawn > 5:
        Cloud7.draw()

    if Cloud8_Spawn > 5:
        Cloud8.draw()

    if Cloud9_Spawn > 5:
        Cloud9.draw()

    
    #PANEL
    if not X_Ray:
        side_panel_1.draw()
        side_panel_2.draw()
        side_panel_3.draw()
        side_panel_4.draw()
        side_panel_5.draw()
        side_panel_6.draw()
        side_panel_7.draw()
        side_panel_8.draw()
        side_panel_9.draw()
        side_panel_10.draw()
        side_panel_11.draw()
        side_panel_12.draw()
        side_panel_13.draw()
        side_panel_14.draw()
        side_panel_15.draw()
        side_panel_16.draw()
    #PANEL
    settings_button.draw()
    
    #toolbar

    if toolbar_button_hovered and not X_Ray:
        toolbar_button_hovered_pos = (toolbar_button.pos[0] + toolbar_button_hover_offset[0],  toolbar_button.pos[1] + toolbar_button_hover_offset[1])
        screen.blit(toolbar_button_hover_image, toolbar_button_hovered_pos)
        screen.draw.text("Toolbar", (100, 50), color="black", fontsize=30)

    else:
        toolbar_button.draw()

    #settings

    if settings_button_hovered and not X_Ray:
        settings_button_hovered_pos = (settings_button.pos[0] + settings_button_hovered_offset[0], settings_button.pos[1] + settings_button_hovered_offset[1])
        screen.blit(settings_button_hover_image, settings_button_hovered_pos)
        screen.draw.text("Settings", (100, 120),color='black', fontsize=30)
    else:
        settings_button.draw()

    #items

    #if delete_button_hovered and not X_Ray:
        #delete_button_hovered_pos = (delete_button.pos[0] + delete_button_hovered_offset[0], delete_button.pos[1] + delete_button_hovered_offset[1])
        #screen.blit(delete_button_hovered_image, delete_button_hovered_pos)
        #screen.draw.text("Items", (110, 460), color='black', fontsize=30)

    #else:
        #delete_button.draw()

    #Tutorial

    if Tutorial_Icon_Hovered and not X_Ray:
        Tutorial_Icon_Hovered_pos = (Tutorial_Icon.pos[0] + Tutorial_Icon_Hovered_Offset[0], Tutorial_Icon.pos[1] + Tutorial_Icon_Hovered_Offset[1])
        screen.blit(Tutorial_Icon_Hovered_Image, Tutorial_Icon_Hovered_pos)
        screen.draw.text('Tutorial', (100, 320), color='black', fontsize=30)
    else:
        Tutorial_Icon.draw()
        
    if Tutorial_Menu_Visible:
        Tutorial_Menu.draw()
        screen.draw.text('TUROTIAL', (460, 210), color=color, fontsize=60)
        screen.draw.text((Tutorial), (410, 280), color='black', fontsize=20)
        
    #spawn_menu
    if spawn_menu_visible:
        spawn_menu.draw()
        screen.draw.text("Goobies 4 Sale", (220, 20), color='black', fontsize=50)
        screen.draw.text("?", (250, 100), color='black', fontsize=30)
        screen.draw.text("?", (350, 100), color='black', fontsize=30)
        screen.draw.text("?",(450, 100),color='black', fontsize=30)
        screen.draw.text("?", (250, 200), color='black',fontsize=30)
        screen.draw.text("?", (350, 200), color='black',fontsize=30)
        
        #ANGEL $30
        if Cash_AMNT >= 30 and Angel_Bought == False:
            Angel_Icon_Visible = True
            Angel_Icon.draw()
            screen.draw.text('$30', (280, 200), color='black', fontsize=30)
            
        #seeker
        if Cash_AMNT >= 50 and Seeker_Bought == False:
            Seeker_Icon.draw()
            screen.draw.text('$50', (390, 200), color='black', fontsize=30)
    
    if Seeker_Bought:
        Seeker.draw()

   #block
    if block_spawn_button_visible and block != bottom_boundary and spawn_menu_visible and spawn_button_cooldown == False and Cash_AMNT > 0:
        block_spawn_button.draw()
        screen.draw.text("$1", (290, 100), color='black', fontsize=30)

    if block_spawned:
        for block in blocks:
            block.draw()
   #exit_menu
    if exit_menu_visible:
        exit_menu.draw()
        screen.draw.text("Play", (750, 80), color="black", fontsize=60)
        screen.draw.text("Exit", (750, 235), color="black", fontsize=60)
        screen.draw.text("Colour", (750, 160), color='black', fontsize=60)

    if exit_button_visible:
        exit_button.draw()

    if play_button_visible:
        play_button.draw()

    if RGB_Button_Visible:
        RGB_Button.draw()

    #screen color
    if New_Color_Change == True:
        screen.fill(tuple(New_Color))

    #Cash
    Cash.draw()
    screen.draw.text(str(Cash_AMNT), (1180, 25), color="black", fontsize=50)
    
    #house
    House.draw()

    if House_Icon_Hovered and not X_Ray:
        House_Icon_Hovered_Pos = (House_Icon.pos[0] + House_Icon_Hovered_Offset[0], House_Icon.pos[1] + House_Icon_Hovered_Offset[1])
        screen.blit(House_Icon_Hovered_Image, House_Icon_Hovered_Pos)
        screen.draw.text("Houses", (100, 250), color='black', fontsize=30)
    else:
        House_Icon.draw()

        
    if House_Menu_Visible:
        House_Menu.draw()
        screen.draw.text("HUOSE Four Sail", (650, 20), color='black', fontsize=50)
        screen.draw.text("?", (630, 150), color='black', fontsize=50)
        screen.draw.text("?", (730, 150), color='black', fontsize=50)
        screen.draw.text("?", (830, 150), color='black', fontsize=50)
        screen.draw.text("?", (930, 150), color='black', fontsize=50)

    if House2_icon_Visible and Cash_AMNT > 10:
        screen.draw.text("$10", (650, 200), color='black', fontsize=30)
        House2_icon.draw()

    if House2_Bought:
        House2.draw()

    if House3_icon_Visible == True and Cash_AMNT > 50:
        House3_icon.draw()
        screen.draw.text("$50", (730, 200), color='black', fontsize=30)

    if House3_Bought:
        House3.draw()

    if House4_icon_Visible and Cash_AMNT > 250:
        screen.draw.text("$250", (830, 200), color='black', fontsize=30)
        House4_icon.draw()

    if House4_Bought:
        House4.draw()

    if House5_icon_Visible and Cash_AMNT > 500:
        screen.draw.text("$500", (930, 200), color='black', fontsize=30)
        House5_icon.draw()
    if House5_Bought:
        #Animation.draw()
        House5.draw()

    #BAT


    if Bat_Icon_Visible and Cash_AMNT > 10 and spawn_menu_visible:
        screen.draw.text("$10", (390, 100), color='black', fontsize=30)
        Bat_Icon.draw()

    if Bat_Spawned:
        Bat.draw()

    #fatso

    if Fatso_Icon_Visible and spawn_menu_visible and Cash_AMNT > 20 and not Fatso_Purchase:
        screen.draw.text("$20", (500, 100), color='black',fontsize=30)
        Fatso_Icon.draw()

    if Fatso_Purchase:
        Fatso.draw()

    #X_RAY

    if X_Ray:
        #house
        screen.draw.text(str(House.x), (House.x, 500), color='green', fontsize=(block.x / 10))
        screen.draw.text("X-Ray Mode", (1000,100), color='black', fontsize=30)
        #block and house
        screen.draw.line((block.x, block.y),(House.x, House.y), "red")
        #bat and house
        screen.draw.line((Bat.x, Bat.y), (House.x, House.y), 'red')
        #fatso and house
        screen.draw.line((Fatso.x, Fatso.y), (House.x,House.y), 'red')
        #fatso and block
        screen.draw.line((Fatso.x, Fatso.y), (block.x,block.y), 'yellow')
        #fatso and bat
        screen.draw.line((Fatso.x, Fatso.y), (Bat.x,Bat.y), 'yellow')
        #clouds
        screen.draw.line((Cloud1.x, Cloud2.y), (Cloud4.x, Cloud9.y), 'black')
        screen.draw.line((Cloud2.x, Cloud6.y), (Cloud8.x, Cloud9.y), 'black')
        screen.draw.line((Cloud5.x, Cloud1.y), (Cloud9.x, Cloud9.y), 'black')

        #bat
        screen.draw.text(str(Bat.y), (Bat.x, Bat.y), color='pink', fontsize=20)
        #block
        screen.draw.text(str(block.x), (block.x, block.y), color='white', fontsize=20)
        #fatso
        screen.draw.text(str(Fatso_Speed), (Fatso.x, Fatso.y), color='black', fontsize=50)
        screen.draw.text(str(Fatso_Value), (Fatso.x, Fatso.y - 50), color='green', fontsize=30)

        screen.draw.text(str(Cursor.y), (500,100), color='pink',fontsize=50)
        screen.draw.text(str(Cursor.x), (600,100), color='pink',fontsize=50)
        #cursor and bat
        screen.draw.line((Cursor.x, Cursor.y), (Bat.x, Bat.y), 'black')
        #angel
        screen.draw.line((Cursor.x, Cursor.y), (Angel.x, Angel.y), 'sky blue')

    
    #cursor
    Cursor.draw()
        


pgzrun.go()

