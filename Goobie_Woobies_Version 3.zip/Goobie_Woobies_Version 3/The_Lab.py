import pgzrun
from random import randint

WIDTH = 800
HEIGHT = 800
TITLE = 'The Lab'

Game_Over = False
Player = Actor('happy_block.png')
Player.y = randint(10, 600)
Player.x = randint(10, 600)

Health = 100
HealthBar = Rect(Player.x - 50, Player.y - 50, Health, 10)
                     
def on_mouse_move(pos):
    global Game_Over
    Player.pos = pos


def update():
    global Health, HealthBar, Game_Over
    HealthBar = Rect(Player.x - 50, Player.y - 50, Health, 10)
    
    if keyboard.S:
        Health -= 1
        print(str(Health))

    if Health <= 0:
        Game_Over = True
        Health = 0
            

    
def draw():
    global HealthBar, Health
    screen.clear()
    Player.draw()
    if Health >= 70:
        screen.draw.filled_rect(HealthBar, 'green')
        
    if Health >= 30 and Health <= 70:
        screen.draw.filled_rect(HealthBar, 'yellow')

    if Health < 30:
        screen.draw.filled_rect(HealthBar, 'red')
                                
    
        
    screen.draw.text((str(Health)), (Player.x - 20, Player.y - 70), color='White', fontsize=30)
    
            


pgzrun.go()
